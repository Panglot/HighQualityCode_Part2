﻿namespace SchoolSystem.Enumerations
{
    public enum Subject
    {
        Bulgarian,
        English,
        Math,
        Programming
    }
}
